# CYaRon 文档
CYaRon 是一个可以帮助你快速生成随机数据的工具库，目标是实现帮您5分钟内生成一组测试数据。

**使用CYaRon**

CYaRon 使用 Python 编写。在安装好 Python 的计算机上，下载 CYaRon 并放置在合适的目录下或使用 Python 自带的 `pip` 安装工具输入命令`pip install cyaron`即可安装 CYaRon。

CYaRon 的工具包可以帮助你写出 Python 数据生成器。通过使用各种工具包，你可以控制输入/输出文件，并将std程序（标程）的输出写入到输出文件中。

要了解 CYaRon 的使用，可以查看本项目的`examples`。

若您对 Python 不熟悉，可看[快速入门教程](https://github.com/luogu-dev/cyaron/wiki/Python-30%E5%88%86%E9%92%9F%E5%85%A5%E9%97%A8%E6%8C%87%E5%8D%97)。

要详细了解 CYaRon 的各部分，可以查看**右侧侧边栏**中的各文档页面。

**贡献**

所有的贡献者请查看[光荣榜](https://github.com/luogu-dev/cyaron/wiki/光荣榜)页面，衷心感谢他们对CYaRon项目的付出。

欢迎您对 CYaRon 做出贡献。若您有希望加入的功能，可以给我们提出 Issue ，或者自己动手实现，然后发起 Pull Request。

有关于如何做出贡献的更详细内容，请查看[如何做出贡献](https://github.com/luogu-dev/cyaron/wiki/%E5%A6%82%E4%BD%95%E5%81%9A%E5%87%BA%E8%B4%A1%E7%8C%AE)。
