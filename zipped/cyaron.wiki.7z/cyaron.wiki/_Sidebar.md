[首页](https://github.com/luogu-dev/cyaron/wiki)

[Python 快速入门](https://github.com/luogu-dev/cyaron/wiki/Python-30%E5%88%86%E9%92%9F%E5%85%A5%E9%97%A8%E6%8C%87%E5%8D%97)

**文档**

[基本入门](https://github.com/luogu-dev/cyaron/wiki/%E5%9F%BA%E6%9C%AC%E5%85%A5%E9%97%A8)

[输入输出 IO](https://github.com/luogu-dev/cyaron/wiki/输入输出-IO)

[图 Graph](https://github.com/luogu-dev/cyaron/wiki/%E5%9B%BE-Graph)

[多边形 Polygon](https://github.com/luogu-dev/cyaron/wiki/%E5%A4%9A%E8%BE%B9%E5%BD%A2-Polygon)

[向量 Vector](https://github.com/luogu-dev/cyaron/wiki/%E5%90%91%E9%87%8F-Vector)

[字符串 String](https://github.com/luogu-dev/cyaron/wiki/%E5%AD%97%E7%AC%A6%E4%B8%B2-String)

[序列 Sequence](https://github.com/luogu-dev/cyaron/wiki/序列-Sequence)

[对拍器 Compare](https://github.com/luogu-dev/cyaron/wiki/%E5%AF%B9%E6%8B%8D%E5%99%A8-Compare)

[工具函数](https://github.com/luogu-dev/cyaron/wiki/工具函数)

[常用常数](https://github.com/luogu-dev/cyaron/wiki/常用常数)

[数学函数](https://github.com/luogu-dev/cyaron/wiki/%E6%95%B0%E5%AD%A6%E5%87%BD%E6%95%B0)

**高级使用**

[提高运行效率](https://github.com/luogu-dev/cyaron/wiki/%E6%8F%90%E9%AB%98%E8%BF%90%E8%A1%8C%E6%95%88%E7%8E%87)

[数学相关](https://github.com/luogu-dev/cyaron/wiki/%E6%95%B0%E5%AD%A6%E7%9B%B8%E5%85%B3)

**贡献相关**

[如何做出贡献](https://github.com/luogu-dev/cyaron/wiki/%E5%A6%82%E4%BD%95%E5%81%9A%E5%87%BA%E8%B4%A1%E7%8C%AE)

[光荣榜](https://github.com/luogu-dev/cyaron/wiki/光荣榜)